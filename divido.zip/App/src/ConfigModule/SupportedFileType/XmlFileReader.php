<?php

namespace App\ConfigModule\SupportedFileType;

use App\ConfigModule\SupportedFileType\FileProcessInterface;
use App\ConfigModule\SupportedFileType\FileReaderAbstract;

final class XmlFileReader extends FileReaderAbstract implements FileProcessInterface {
	
	
	/**
	 * @var array
	 */
	private $files;
	
	public function __construct($files = array()) {
		$this->files = $files;
	}
	
	
	/**
	 * Check provided file is valid or not
	 * @param string $file
	 * @throws Exception if the provided file content is not valid.
	 * @return array
	 */
	public function checkFileValid(string $file) {
		try {
			$xmlcontent = @simplexml_load_string($this->fileContentReader($file));
			if(!$xmlcontent) {
				throw new \Exception("Invalid XML - ". $file);
			} else {
				return json_decode(json_encode($xmlcontent), TRUE);
			}
		} catch (\Exception $e) {
			exit('Message: ' .$e->getMessage());
		}
	}
	
	/**
	 * Get Content from provided File(s)
	 * @return array
	 */
	public function getContent() {
		$content = [];
		foreach($this->files as $file) {
			$content = array_merge($content, $this->checkFileValid($file));
		}
		return $content;
	}
	
}