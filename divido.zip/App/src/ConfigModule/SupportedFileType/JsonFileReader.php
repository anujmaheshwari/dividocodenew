<?php

namespace App\ConfigModule\SupportedFileType;

use App\ConfigModule\SupportedFileType\FileReaderAbstract;
use App\ConfigModule\SupportedFileType\FileProcessInterface;

final class JsonFileReader extends FileReaderAbstract implements FileProcessInterface {
	
	/**
	 * @var array
	 */
	private $files;
	
	public function __construct($files = array()) {
		$this->files = $files;
	}
	
	/**
	 * Check provided file is valid or not
	 * @param string $file
	 * @throws Exception if the provided file content is not valid.
	 * @return array
	 */
	public function checkFileValid(string $file) {
		try {
			$jsoncontent = json_decode($this->fileContentReader($file), TRUE);
			if(json_last_error() === JSON_ERROR_NONE) {
				return $jsoncontent;
			} else {
				throw new \Exception("Json content is not valid - ". $file);			
			}
			
		} catch (\Exception $e) {
			exit('Message: ' .$e->getMessage());
		}
	}
	
	/**
	 * Get Content from provided File(s)
	 * @return array
	 */
	public function getContent() {
		$content = [];
		foreach($this->files as $file) {
			$content = array_merge($content, $this->checkFileValid($file));
		}
		return $content;
		
	}
	
	

}