<?php

namespace App\src\ConfigModule\SupportedFileType;

Abstract class FileReaderAbstract {
	
	/**
	 * Provide content from file when file is exists
	 * @param string $file
	 * @throws Exception if the provided file is not exist.
	 * @return mixed
	 */
	public function fileContentReader(string $file) {
		try {
			if(file_exists($file)) {
				$filecontent = file_get_contents($file);
				return $filecontent;
			}
			throw new \Exception("File not found - ". $file);
		}
		catch(\Exception $e) {
			exit("Message : Provided file is not exist ". $file);
		}
	}
	
}

?>