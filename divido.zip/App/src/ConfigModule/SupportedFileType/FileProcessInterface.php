<?php

namespace App\ConfigModule\SupportedFileType;

interface FileProcessInterface {

	/**
	 * To check the provided file is valid or not
	 *
	 * @param string $file
	 */
	public function checkFileValid(string $file);

	/**
	 * This is for to provide a config file data
	 */
	public function getContent();
}