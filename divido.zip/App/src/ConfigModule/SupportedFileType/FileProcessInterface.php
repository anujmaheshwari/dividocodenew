<?php

namespace App\src\ConfigModule\SupportedFileType;

interface FileProcessInterface {
	
	public function checkFileValid(string $file);
	
	public function makeParser();
}