<?php

namespace App;

class ConfigFileParser {

	/**
	 * @var array 
	 */
	public $supportedfilesType;
	
	public function __construct($supportedfilesType = array()) {
		$this->supportedfilesType = $supportedfilesType;
	}
	
	/**
	 * This function is to provide all collected data from config data
	 * 
	 * @return mixed
	 * 
	 */
	public function getCombineConfig() {
		$combineConfig = [];	
		foreach($this->supportedfilesType as $supportedfileType) {
			$combineConfig = array_merge($combineConfig, $supportedfileType->getContent());
		}
		return $combineConfig;
	}
	
	/**
	 * This function is to provide set of data as per config key
	 * 
	 * @return mixed
	 * 
	 */
	public function getValueByKey(string $key, $data = array()) {
		if(is_array($data) && $key !== "") {
			$arraykeys = explode(".", $key);
			foreach($arraykeys as $key) {
				if(!array_key_exists($key, $data)) {
					return null;
				}
				$data = $data[$key];
			}
			return $data;
		}
	}

}