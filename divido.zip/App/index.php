<?php

namespace App;

require 'src/ConfigFileParser.php';

use App\src\ConfigFileParser as ConfigFileParser;
use App\src\ConfigModule\SupportedFileType\JsonFileReader as JsonFileReader;
use App\src\ConfigModule\SupportedFileType\XmlFileReader as XmlFileReader;


$ConfigFileParser = new ConfigFileParser(
	[
		new JsonFileReader([__DIR__.'/assets/files/prod.json']),
		new JsonFileReader([__DIR__.'/assets/files/prod.json']),
		new XmlFileReader([__DIR__.'/assets/files/prod.xml']),
	]
	);
$dataConfig = $ConfigFileParser->getCombineConfig();
$mysqlusernamefromxml = $ConfigFileParser->getValueByKey("mysql.username", $dataConfig);
$mysqlpasswordfromxml = $ConfigFileParser->getValueByKey("mysql.password", $dataConfig);

$mysqlusername = $ConfigFileParser->getValueByKey("database.host", $dataConfig);
$mysqlpassword = $ConfigFileParser->getValueByKey("database.port", $dataConfig);

print_r('MYSQL USERNAME from prod.xml: '. $mysqlusernamefromxml . "<br/>");
print_r('MYSQL PASSWORD from prod.xml: '. $mysqlpasswordfromxml . "<br/>");

print_r('MYSQL USERNAME from prod.json: '. $mysqlusername . "<br/>");
print_r('MYSQL PASSWORD from prod,json: '. $mysqlpassword . "<br/>");



?>