<?php

require_once __DIR__.'/../src/ConfigFileParser.php';
require_once __DIR__.'/../src/ConfigModule/SupportedFileType/JsonFileReader.php';

use PHPUnit\Framework\TestCase;
use App\src\ConfigFileParser as ConfigFileParser;
use App\src\ConfigModule\SupportedFileType\JsonFileReader as JsonFileReader;

class ConfigFileParserTest extends TestCase {
	
	public function testObjectCreatedOrNot() {
		$ConfigFileParser = new ConfigFileParser();
		$this->assertIsObject($ConfigFileParser);
	}
	
	public function testSupportedFilesTypeIsNotArray() {
		$ConfigFileParser = new ConfigFileParser("");
		$this->assertIsNotArray($ConfigFileParser->supportedfilesType);
	}
	
	public function testSupportedFilesTypeIsEmptyArray() {
		$ConfigFileParser = new ConfigFileParser([]);
		$this->assertIsArray($ConfigFileParser->supportedfilesType);
	}
	
	public function testSupportedFilesTypeIsArray() {
		$ConfigFileParser = new ConfigFileParser([new JsonFileReader()]);
		$arr = $ConfigFileParser->supportedfilesType;
		$this->assertEquals(1, count($arr));
	}
	
	public function testDataIsAvailable() {
		$ConfigFileParser = new ConfigFileParser([new JsonFileReader([__DIR__."../../assets/files/prod.json"])]);
		$data = $ConfigFileParser->getCombineConfig();
		$this->assertNotEmpty($data);
	}
	
	public function testProvidedKeyDataIsAvailable() {
		$ConfigFileParser = new ConfigFileParser([new JsonFileReader([__DIR__."../../assets/files/prod.json"])]);
		$data = $ConfigFileParser->getCombineConfig();
		$this->assertEquals("mysql", $ConfigFileParser->getValueByKey("database.host", $data));
	}
	
}

?>