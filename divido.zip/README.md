
# Config Module

This Module is for : combined multiple provided config 
file (i.e. xml, json) content.

Currently supported Files: Xml, JSON.

We can extends with other file format without manipulating 
other file format class logic.

And User can access these config variable value by 
using a dot notation rather than using Array.

Old Way to access a data from array:

Like If we want to access username and password of mysql.
Using array : we do it in below way:
mysql['username'] OR mysql['password']

New Way to access a data from array:

Now from this config module, user can access the same
variable by dot notation.
Example: mysql.username OR mysql.password

# Prerequisite: 

Required things: 
- XAMPP Server
- PHPUnit - for Testing


Reference for PHPUnit Framework: 
https://phpunit.readthedocs.io/en/9.5/installation.html

# Written Code Test

Go to our divido folder:
* Before run below command , Just make sure PHPunit is installed

- php vendor/bin/phpunit 

# For Code run

Go to App folder: run index.php file.









