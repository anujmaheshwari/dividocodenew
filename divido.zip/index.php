<?php

require "vendor/autoload.php";

use App\ConfigFileParser as ConfigFileParser;
use App\ConfigModule\SupportedFileType\JsonFileReader as JsonFileReader;
use App\ConfigModule\SupportedFileType\XmlFileReader as XmlFileReader;

$ConfigFileParser = new ConfigFileParser(
	[
		new JsonFileReader([__DIR__.'/assets/files/prod.json']),
		new JsonFileReader([__DIR__.'/assets/files/prod.json']),
		new XmlFileReader([__DIR__.'/assets/files/prod.xml']),
	]
);

$dataConfig = $ConfigFileParser->getCombineConfig();
$mysqlusernamefromxml = $ConfigFileParser->getValueByKey("mysql.username", $dataConfig);
$mysqlpasswordfromxml = $ConfigFileParser->getValueByKey("mysql.password", $dataConfig);

$mysqlusername = $ConfigFileParser->getValueByKey("database.host", $dataConfig);
$mysqlpassword = $ConfigFileParser->getValueByKey("database.port", $dataConfig);

print_r('MYSQL USERNAME from prod.xml: '. $mysqlusernamefromxml . "<br/>");
print_r('MYSQL PASSWORD from prod.xml: '. $mysqlpasswordfromxml . "<br/>");

print_r('MYSQL USERNAME from prod.json: '. $mysqlusername . "<br/>");
print_r('MYSQL PASSWORD from prod,json: '. $mysqlpassword . "<br/>");


?>